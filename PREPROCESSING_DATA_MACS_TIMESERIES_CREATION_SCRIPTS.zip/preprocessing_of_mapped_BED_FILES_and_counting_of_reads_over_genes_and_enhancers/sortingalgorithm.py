from __future__ import print_function
from operator import itemgetter
from sys import argv

script, name = argv
#print name

openseq=open(name)
string2=name.split('.bed')[0]+"_chr_changed"
for i in range(4): lineseq = openseq.readline()
#print lineseq[0]
#del lineseq[0]
#del lineseq[0]
#del lineseq[0]
#del lineseq[0]
#lineseq.pop(index)

chrcolumndict={'chr1':'1', 'chr2':'2','chr3':'3', 'chr4':'4', 'chr5':'5', 'chr6':'6', 'chr7':'7', 'chr8':'8', 'chr9':'9', 'chr10':'10', 'chr11':'11', 'chr12':'12',
		 'chr13':'13','chr14':'14', 'chr15':'15', 'chr16':'16', 'chr17':'17', 'chr18':'18', 'chr19':'19', 'chr20':'20', 'chr21':'21', 'chr22':'22', 'chrX':'23', 'chrY':'24', 'chrMT':'0'}

lineseq = openseq.readline()
file2 = open(string2, "w")
while lineseq<>'':
	
	getpeak=lineseq.split("\t")
	chrom=chrcolumndict[getpeak[0]]
	if '0'<>chrom:
		string = chrom + '\t' + getpeak[1] + '\t' + getpeak[2] + '\t' + getpeak[5] + '\n'
		#string = str(chrcolumndict[getpeak[0]]) + '\t' + getpeak[1] + '\t' + getpeak[2] + '\n'
		#vector[k] = [int(getpeak[0]), int(getpeak[1]), int(getpeak[2])]
	
		file2.write(string)
	lineseq = openseq.readline()	
#sortedvector = sorted(vector, key=itemgetter(0,1,2))

#del vector


#for sorted_v in sortedvector:
	
#	if sorted_v[0]<>0:
		#string = str(sortedvector[j][0]) + "\t" +  str(sortedvector[j][1]) + "\t" +  str(sortedvector[j][2]) + "\t" +"\n"
		
#		print(*(sorted_v[0], sorted_v[1], sorted_v[2]), sep="\t", end='\n', file=file2)
		
		#file2.write(string)
		
file2.close()
#print "the end"
openseq.close()
