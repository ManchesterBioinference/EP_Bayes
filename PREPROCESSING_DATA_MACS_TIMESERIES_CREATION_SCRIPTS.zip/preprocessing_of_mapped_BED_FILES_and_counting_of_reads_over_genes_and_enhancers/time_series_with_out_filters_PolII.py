import numpy as np

name = 'PolII'
name_2 = 'Homo_sapiens.GRCh37.75.gtf_filtered_gene_joint_2_cleaned_chr_sorted_sorted'
name_2 = 'ENSEMBL_v69_GENES_5_bins'

h_=np.loadtxt('{0}_NoTreatmin_tagged.txt'.format(name_2), delimiter = '\t', dtype = str)
a=np.loadtxt('{0}_5min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,)) 
b=np.loadtxt('{0}_10min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
c=np.loadtxt('{0}_20min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
d=np.loadtxt('{0}_40min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
e=np.loadtxt('{0}_80min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
f=np.loadtxt('{0}_160min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
g=np.loadtxt('{0}_320min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
h=np.loadtxt('{0}_640min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
i=np.loadtxt('{0}_1280min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))

stacked = np.column_stack((h_,a,b,c,d,e,f,g,h,i)) # a,

np.savetxt('{0}_unfiltered_count_{1}'.format(name_2,name), stacked, fmt = '%s', delimiter = '\t')


name_2 = 'common_region_peaks_extended_less_time_points_sorted'


h_=np.loadtxt('{0}_NoTreatmin_tagged.txt'.format(name_2), delimiter = '\t', dtype = str)
a=np.loadtxt('{0}_5min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,)) 
b=np.loadtxt('{0}_10min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
c=np.loadtxt('{0}_20min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
d=np.loadtxt('{0}_40min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
e=np.loadtxt('{0}_80min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
f=np.loadtxt('{0}_160min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
g=np.loadtxt('{0}_320min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
h=np.loadtxt('{0}_640min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))
i=np.loadtxt('{0}_1280min_tagged.txt'.format(name_2), delimiter = '\t', dtype = str, usecols=(3,))

stacked = np.column_stack((h_,a,b,c,d,e,f,g,h,i)) # 

np.savetxt('{0}_unfiltered_count_{1}'.format(name_2,name), stacked, fmt = '%s', delimiter = '\t')



