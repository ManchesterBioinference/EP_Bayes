#from scipy import *
from numpy  import *
from sys import argv

script, name = argv

string2=name.split('.txt')[0]+'_removed'

openseq=open(name)

file2 = open(string2, 'w')

total=0

lineseq = openseq.readline()
lineseq_new = 'start'	
file2.write(lineseq)

while lineseq_new<>'':
	
	lineseq_new = openseq.readline()
	if lineseq_new <> lineseq: 

		file2.write(lineseq_new)
		
		
	else:	
		total+=1	
	
	lineseq = lineseq_new

file2.close()
print "total=", total		
