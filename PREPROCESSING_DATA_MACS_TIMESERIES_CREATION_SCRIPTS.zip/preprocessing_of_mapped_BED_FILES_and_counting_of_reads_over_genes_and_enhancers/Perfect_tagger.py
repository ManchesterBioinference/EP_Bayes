from sys import argv
import numpy as np
import re
script, name_1, name_2, time = argv
#print name

string2 = name_1+'_'+time+"min_tagged.txt"


#the actuall program
#--------------------------------------------------------------------------------------------------------------------



def peaks_chrom_getter(chrom):	
	open_peaks=open(name_1)
	next_peak = open_peaks.readline()
	peaks = []
	while next_peak <> '':
		peak = next_peak.split('\t')		
		if peak[0] == chrom: 
			peaks.append(peak) 		
		next_peak = open_peaks.readline()	
	open_peaks.close()
	return np.array(peaks)

def reads_chrom_getter(chrom):	
	open_seq=open(name_2)
	next_read = open_seq.readline()
	reads = []
	while next_read <> '':
		read = next_read.split('\t') 
		if read[0] == chrom:
			reads.append(read)
		next_read = open_seq.readline()
	open_seq.close()
	return np.array(reads)	


chroms=['chr1', 'chr2','chr3', 'chr4', 'chr5', 'chr6', 'chr7', 'chr8', 'chr9', 'chr10', 'chr11', 'chr12','chr13','chr14', 'chr15', 'chr16', 'chr17', 'chr18', 'chr19', 'chr20', 'chr21', 'chr22', 'chrX', 'chrY']

output = open(string2, 'w')


for chrom in chroms:


	
	peaks = np.array(peaks_chrom_getter(chrom)[:,[1,2]],int)
	reads = np.array(reads_chrom_getter(chrom)[:,[1,2]],int)
	state = 0
	intersections=0
	cardinter=0
	j_last=0
	for peak in peaks:
		j=j_last
		tag=0
		state=0
		cardinter=0
		while 1:
			j+=1

			
			
			if (reads[j,1]>=peak[0] and reads[j,1]<=peak[1]) or (reads[j,0]>=peak[0] and reads[j,0]<=peak[1]):
				if state==0: j_last=j									
				cardinter=1
				tag+=1
				state=1
			else:
				cardinter=0
					
			if state==1 and cardinter==0: 
			
				string = '{0}\t{1[0]}\t{1[1]}\t{2}\n'.format(chrom,peak,tag)
				output.write(string)
				
				state=0
				break

			elif (state==1) and (j==len(reads)-1):
				string = '{0}\t{1[0]}\t{1[1]}\t{2}\n'.format(chrom,peak,tag)
				output.write(string)
				break	

			
			elif (state==0 and j==len(reads)-1) or (state==0 and peak[1] < reads[j,1]):
				string = '{0}\t{1[0]}\t{1[1]}\t{2}\n'.format(chrom,peak,tag)
				output.write(string)
				break
			
			
				
	
				
print "the end"		
output.close()
#--------------------------------------------------------------------------------------------------------------------
#end	
