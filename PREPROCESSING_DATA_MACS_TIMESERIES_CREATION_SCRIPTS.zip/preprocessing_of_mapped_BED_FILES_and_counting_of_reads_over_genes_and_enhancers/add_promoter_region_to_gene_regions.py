import numpy as np

upstream_TSS = 300

name_of_time_series_promoter_file_for_TSS_start = "Homo_sapiens.GRCh37.75.gtf_filtered_gene_joint_2_cleaned_chr_sorted_sorted_ordered_0_indexed.gz"

name_of_gene_file = name_of_time_series_promoter_file_for_TSS_start[:-3] + "_{0}".format(upstream_TSS)

def create_GENE_file(upstream_TSS):

	data = np.loadtxt(name_of_time_series_promoter_file_for_TSS_start, dtype = str,  delimiter = '\t')	
	plus_strand = data[:, 3] == '+'

	data[plus_strand, 1] = data[plus_strand, 1].astype(int) - upstream_TSS
	data[np.invert(plus_strand), 2] = data[np.invert(plus_strand), 2].astype(int) + upstream_TSS

	np.savetxt(name_of_gene_file, data, fmt = '%s', delimiter = '\t')

create_GENE_file(upstream_TSS)


