import re
import numpy as np
from sys import argv

script, name = argv

input_=open(name)
output = open(name+'_chr','w')
next_line=input_.readline() 

dict_={'1':'chr1', '2':'chr2', '3':'chr3', '4':'chr4', '5':'chr5', '6':'chr6', '7':'chr7', '8':'chr8', '9':'chr9', '10':'chr10', '11':'chr11', '12':'chr12', '13':'chr13', '14':'chr14', '15':'chr15', '16':'chr16', '17':'chr17', '18':'chr18', '19':'chr19', '20':'chr20', '21':'chr21', '22':'chr22', '23':'chrX', '24':'chrY'}

while next_line <> '':
	line=next_line.split('\t')
	line[0] = dict_[line[0]]
	output.write('\t'.join(line))
	next_line=input_.readline()	
input_.close()
output.close()
