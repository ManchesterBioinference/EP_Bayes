import numpy as np

#chrdict={'chr1':1, 'chr2':2,'chr3':3, 'chr4':4, 'chr5':5, 'chr6':6, 'chr7':7, 'chr8':8, 'chr9':9, 'chr10':10, 'chr11':11, 'chr12':12,
#		 'chr13':13,'chr14':14, 'chr15':15, 'chr16':16, 'chr17':17, 'chr18':18, 'chr19':19, 'chr20':20, 'chr21':21, 'chr22':22, 'chrX':23, 'chrY':24, 'chrMT':0}

no_TREAT_added_in_construction = False

minutes = [5,10,20,40,80,160,320]

if no_TREAT_added_in_construction: minutes = [0] + minutes

p_value = ["1e-05", "1e-07", "1e-9", "1e-11"][-1]

mode = ["no_control", "no_lambda"][1]

files_to_open = ["{0}minERa_relaxed_{1}_{2}_peaks.bed".format(t_min, p_value, mode) for t_min in minutes]

concatenate = np.array([]).reshape(0,4)

for time, file_ in zip(minutes, files_to_open):
	
	concatenate_ = np.loadtxt(file_, dtype = str)[:,:3]
	time_to_add = np.zeros(len(concatenate_), "|S7")
	time_to_add[:] = '{0}min'.format(time)
	concatenate_2 = np.column_stack((concatenate_, time_to_add))
	concatenate = np.r_[concatenate, concatenate_2] 

for num_chr,chrom in enumerate(map(lambda x: 'chr{0}'.format(x), np.r_[np.arange(1,23).astype(str), ['X', 'Y']])):
	concatenate[concatenate[:,0] == chrom, 0] = str(num_chr+1)

name_of_concat_file = "concat_test_{0}_{1}".format(p_value, mode)
name_of_merged_file = "merged_regions_merged_bed_{0}_{1}".format(p_value, mode)

np.savetxt(name_of_concat_file, concatenate, fmt = '%s', delimiter= "\t")

import os

os.system("sort -k 1,1n -k 2,2n -k 3,3n {0} > {0}_sorted_bed".format(name_of_concat_file))

os.system("python chr_changer.py {0}_sorted_bed".format(name_of_concat_file))

os.system("bedtools merge -i {0}_sorted_bed_chr -n -nms > {1}".format(name_of_concat_file, name_of_merged_file))

peaks = np.loadtxt(name_of_merged_file, delimiter = "\t", dtype = str)

merged_peaks_without_ones = peaks[peaks[:,-1].astype(int) > 1]

merged_peaks_without_ones_0_indexed = np.column_stack((merged_peaks_without_ones[:, :3], np.arange(len(merged_peaks_without_ones))))

if no_TREAT_added_in_construction: 
	merged_regions_merged_bed = "common_region_peaks_extended_less_time_points_corrected_{2}_0_indexed_{0}_{1}".format(p_value, mode, "No_Treat")

elif (p_value == str(1e-11)) and (mode == "no_lambda"):
	merged_regions_merged_bed = "common_region_peaks_extended_less_time_points_corrected_0_indexed"
else: 
	merged_regions_merged_bed = "common_region_peaks_extended_less_time_points_corrected_0_indexed_{0}_{1}".format(p_value, mode)

np.savetxt(merged_regions_merged_bed, merged_peaks_without_ones_0_indexed, fmt = '%s', delimiter= "\t")

