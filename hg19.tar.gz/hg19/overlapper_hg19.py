import shlex, subprocess
import numpy as np
import re

name_of_files = np.loadtxt("list_of_files.txt", dtype = str)

pwd = "/home/tom/cistrom_data_sets"
hg = 'hg19'

name_to_open = 'common_region_peaks_extended_less_time_points_sorted_chr_names_0_indexed'
#name_of_file_clustered = "common_region_peaks_extended_less_time_points_sorted_unfiltered_count_concat_2012-03_PolII_PolII_100_0.2"
#name_of_file_clustered = 'common_region_peaks_extended_less_time_points_sorted_unfiltered_count_concat_ER_300_-1.0'

name_of_file_clustered = "common_region_peaks_extended_less_time_points_sorted_unfiltered_count_concat_ER_PolII_300_-1.0"

#name_to_open = "Homo_sapiens.GRCh37.75.gtf_filtered_gene_joint_2_cleaned_chr_sorted_sorted_ordered_0_indexed"
#name_of_file_clustered = "Homo_sapiens.GRCh37.75.gtf_filtered_gene_joint_2_cleaned_chr_sorted_sorted_unfiltered_count_concat_ER_300_-1.0"
#name_of_file_clustered = "Homo_sapiens.GRCh37.75.gtf_filtered_gene_joint_2_cleaned_chr_sorted_sorted_ordered_0_indexed_300_unfiltered_count_concat_ER_PolII_300_-1.0"


#name_to_open = "common_region_peaks_extended_less_time_points_sorted_chr_names_0_indexed"
#name_of_file_clustered = "common_region_peaks_extended_less_time_points_sorted_unfiltered_count_concat_ER_300_-1.0"

motif_enrichments = [[]]*len(np.loadtxt(name_to_open, dtype = str))

for name_of_file in name_of_files:

	name_of_file_ = pwd + "/" + hg + "/" + name_of_file	
	command_line = "windowBed -a {0} -b {1} -sw -l 0 -r 0".format(name_of_file_, name_to_open)
	args = shlex.split(command_line)

	proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
	output_raw = proc.stdout.read()
	
	if len(output_raw):
		output = re.findall(r"[\w^+^-^//^,^.]+", output_raw)
		output = np.array(output).reshape(len(output)/9, 9)
		np.savetxt(name_of_file[:-4] + '_ER_peaks_overlap.txt', output, fmt = '%s', delimiter = '\t')
		#np.loadtxt(name_of_file[:-4] + '_ER_peaks_overlap.txt', str)
		for index_of_peak, peak_overlap in zip(output[:, 8].astype(int), output[:, :5]):
			motif_enrichments[index_of_peak] = motif_enrichments[index_of_peak] + [list(peak_overlap[[0,1,2,4]]) + [peak_overlap[3].split("_")[-1]] + [name_of_file.split("_")[1]] + [name_of_file.split("_")[0]]]

#["_".join(name_of_file.split("_")[:2])]] - tells which file it comes from

file_1 = open("enriched_peaks", 'w')
peaks = np.loadtxt(name_to_open, dtype = str)
for index in [ind for ind, el in enumerate(motif_enrichments) if len(el)]:
	array = motif_enrichments[index]
	for el in array:
		
		save = '\t'.join(np.r_[peaks[index], el])
		save += '\n'
		file_1.write(save)

file_1.close()

enriched_peaks = np.loadtxt("enriched_peaks", str)
legend = np.unique(enriched_peaks[:,9])
map_legend = {}
for ind, el in enumerate(legend): map_legend[el] = ind

count_matrix = np.zeros((len(motif_enrichments), len(legend)), bool)

for el in enriched_peaks:
	count_matrix[int(el[3]), map_legend[el[-2]]] = True

np.save("enrichment_matrix", count_matrix)



survived = np.loadtxt('{0}_survived_indexes'.format(name_of_file_clustered)).astype(int) # saved during filtering

labels = np.loadtxt('{0}_labels'.format(name_of_file_clustered), str, delimiter = ",")[1:,1].astype(int) # from EP clustering

count_matrix[survived].sum(0)/float(survived.shape[0])

from scipy.stats import binom

ps = count_matrix[survived].sum(0)/float(survived.shape[0])

prob = np.zeros((len(np.unique(labels)), len(ps)))

enrichments_counts = prob.astype(int)
#sorts 	

labels_count = np.histogram(labels, bins = range(0,max(labels)+2))[0][1:]
sorted_counts_labels = np.argsort(labels_count)[::-1]
sorted_counts = labels_count[sorted_counts_labels]

sorted_labels = np.unique(labels)[sorted_counts_labels]


def sorted_labels_func():
	
	time_series_survived = np.loadtxt(name_of_file_clustered, dtype = np.float, delimiter = ",")

	means = []
	for ind, label in enumerate(sorted_labels):

		mean = (time_series_survived[label == labels, :8]).mean(0)

		means += [mean]

	means = np.array(means)

	ind = np.lexsort((means[:,7],means[:,6],means[:,5],means[:,4],means[:,3],means[:,2],means[:,1],means[:,0]))
	return ind

ind_sort = sorted_labels_func()

sorted_labels = sorted_labels[ind_sort]

for index_1, label in enumerate(sorted_labels):

	n = np.sum(labels == label)
	xs = count_matrix[survived][labels == label].sum(0)
	
	for index_2, p in enumerate(ps):
		p = ps[index_2]
		x = xs[index_2]
		prob[index_1, index_2] = 1. - binom.cdf(x-1, n, p)

		enrichments_counts[index_1, index_2] = x


		
#np.savetxt("common_region_peaks_extended_less_time_points_sorted_unfiltered_count_concat_2012-03_PolII_PolII_100_probabilities_of_enrichment", prob, delimiter = "\t", fmt = '%0.8f', header = '\t'.join(legend))

np.savetxt("{0}_probabilities_of_enrichment".format(name_of_file_clustered), prob, delimiter = "\t", fmt = '%0.8f', header = '\t'.join(legend))

mask_legend = np.ones_like(legend).astype(bool)

#mask_legend[10:18] = False
#mask_legend[25:27] = False

file1 = open(name_of_file_clustered + "_enrichment", "w")
for i in range(len(prob)):
	 file1.write(','.join(legend[(prob[i] < 0.01)*mask_legend]) + "\n")

file1.close()

from matplotlib import pyplot as plt
from pandas import *

idx = Index(np.unique(labels))
df = DataFrame(np.c_[prob[:, mask_legend], sorted_counts[ind_sort][:,None]], index=idx, columns=np.r_[legend[mask_legend], ["Count"]])
vals = np.around(df.values,2)
normal = plt.Normalize(prob[:,mask_legend].min()-0.3, prob[:,mask_legend].max()+0.3)

rise = np.zeros_like(vals).astype(bool)
time_series = np.loadtxt(name_of_file_clustered, delimiter = ",")

for ind, label in enumerate(sorted_labels):
	mean = (time_series[label == labels]).mean(0)

	if mean[0] < mean[1]: rise[ind, :-1] = np.ones(len(legend[mask_legend]))

vals_enrich = np.c_[enrichments_counts[:,mask_legend], sorted_counts[ind_sort][:,None]]

matrix_colour = plt.cm.hot(normal(vals))
mask_encriched = vals < 0.01
matrix_colour[mask_encriched*rise] = np.array([0.0, 0.5019607843137255, 0.0, 0.6])

matrix_colour[mask_encriched*np.invert(rise)] = np.array([0.0, 0.5019607843137255, 0.0, 0.3])

mask_depleted = vals > 0.99

white = [1., 1., 1., 1.]

mask_niether = np.invert(mask_encriched + mask_depleted)

matrix_colour[mask_depleted*rise] = np.array([0.768, 0.090, 0.090, 0.3])

matrix_colour[mask_depleted*np.invert(rise)] = np.array([0.768, 0.090, 0.090, 0.6])

matrix_colour[mask_niether] = [0.815, 0.803, 0.803, 1.]

matrix_colour[:, -1] = white


fig = plt.figure(figsize=(24,10))
ax = fig.add_subplot(111, frameon=True, xticks=[], yticks=[])
the_table=plt.table(cellText=vals_enrich, rowLabels=df.index, colLabels=df.columns, 
                    colWidths = [0.036]*vals.shape[1], loc='center', 
                    cellColours=plt.get_cmap('Spectral')(normal(vals)))

fig = plt.figure(figsize=(24,10))
ax = fig.add_subplot(111, frameon=True, xticks=[], yticks=[])
the_table=plt.table(cellText=vals_enrich, rowLabels=df.index, colLabels=df.columns, 
                    colWidths = [0.036]*vals.shape[1], loc='center', 
                    cellColours=matrix_colour)






#count_matrix[survived][labels == 1].sum(0)/float(count_matrix[survived].sum(0)[0])


#for i in $( ls ); do
#	echo item: $i
#done
